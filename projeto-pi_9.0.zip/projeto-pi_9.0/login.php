<?php
    session_start();
    require_once("conexao.php");
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $email = $_POST["email"];
        $senha = $_POST["senha"];

        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email");
        $stmt->execute([':email' => $email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if($usuario && password_verify($senha, $usuario['senha'])){
         $_SESSION['usuario_id'] = $usuario['idusuario'];
         $_SESSION['nome'] = $usuario['nome'];
         $_SESSION['tipo'] = $usuario['tipo'];

         if($usuario['tipo'] == 'funcionario'){
            header("Location: dashboard_funcionario.php");
         } else {
            header("Location: dashboard_cliente.php");
         }
         exit;
      } else {
         echo "Email ou senha incorretos.";
      }
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Login</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
   </head>
   <body class="main-layout position_head">
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <header>
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.jpg" alt="Logo da loja TI Games" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item ">
                                 <a class="nav-link" href="index.html">Início</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="sobre.html">Sobre nós</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="produtos.html">Nossos produtos</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="loja.html">Loja</a>
                              </li>
                              <li class="nav-item d_none login_btn">
                                 <a class="nav-link" href="cadastro.php">Cadastro</a>
                              </li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <div id="contact" class="contact">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <form id="request" class="main_form" method="POST" action="login.php">
                     <div class="row">
                        <div class="col-md-12 ">
                           <h3>Login</h3>
                        </div>
                        <div class="col-md-12 ">
                           <label for="email"><p>E-mail:</p></label>
                           <input class="contactus" placeholder="exemplo@gmail.com" type="email" name="email" id="email" required> 
                        </div>
                        <div class="col-md-12">
                           <label for="senha"><p>Senha:</p></label>
                           <input class="contactus" placeholder="******" type="password" name="senha" id="senha" required>                          
                        </div>
                        <div class="col-md-12">
                           <button class="send_btn"><p>Login</p></button>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
         <div class="container-fluid">
            <div class="map_section">
               <div id="map">
                  <img src="images/assassinoscreed.jpg" alt="">
               </div>
            </div>
         </div>
      </div>
      </div>
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="https://maps.app.goo.gl/mvAChRx4Qs8vrUDn9"><i class="fa fa-map-marker" aria-hidden="true"></i></a><br>Localização</li>
                        <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a><br>+55 (61) 91234-5678</li>
                        <li><a href="" type="email"><i class="fa fa-envelope" aria-hidden="true"></i></a><br>lojatigames@gmail.com</li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>NOVOS GAMES COMERCIO VAREJISTA DE JOGOS - CPJ: 12.345.678/9101-12 :copyright: Todos os direitos reservados. <br>2024 System TI Games v1.0</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>